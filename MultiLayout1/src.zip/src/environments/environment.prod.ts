export const environment = {
  production: true,
  ApiUrl: "https://testapi.skilllens.com/api/"
};
