export interface IRegister {
    userName: string;
    email: string;
    phoneNumber: string;
    password: string;
}

export interface ILogin {
    userName: string;
    password: string;
}