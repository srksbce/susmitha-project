export interface IEmployee
{
    empId:number;
    deptId:number;
    empName:string;

}